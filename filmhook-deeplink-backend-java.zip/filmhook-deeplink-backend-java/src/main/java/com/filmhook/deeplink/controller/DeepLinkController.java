package com.filmhook.deeplink.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;

@RestController
@RequestMapping("/share")
public class DeepLinkController {

    @GetMapping("/{id}")
    public ResponseEntity<Void> redirectToApp(@PathVariable String id) {
        String redirectUrl = "https://filmhookapps.com/share/" + id;
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(URI.create(redirectUrl));
        return new ResponseEntity<>(headers, HttpStatus.FOUND);
    }
}
