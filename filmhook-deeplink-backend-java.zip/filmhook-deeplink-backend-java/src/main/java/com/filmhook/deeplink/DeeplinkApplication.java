package com.filmhook.deeplink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeeplinkApplication {
    public static void main(String[] args) {
        SpringApplication.run(DeeplinkApplication.class, args);
    }
}
